# Drum-Kit
Consists of a web page with small drum kit. Keyboard keys can be used to play different drums.
